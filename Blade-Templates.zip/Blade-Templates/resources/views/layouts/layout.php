<!-- resources/views/layouts/layout.blade.php -->
<!DOCTYPE HTML>
<html>
    <head>
        <title>@yield('title', 'Massively Theme')</title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="{{ asset('css/main.css') }}" />
        @yield('styles')
    </head>
    <body class="is-preload">

        <!-- Header -->
        <header id="header">
            <a href="{{ url('/') }}" class="logo">Massively</a>
        </header>

        <!-- Nav -->
        <nav id="nav">
            <ul class="links">
                <li><a href="{{ url('/') }}">Home</a></li>
                <li><a href="{{ url('/about') }}">About</a></li>
                <li><a href="{{ url('/contact') }}">Contact</a></li>
            </ul>
        </nav>

        <!-- Main Content -->
        <div id="main">
            @yield('content')
        </div>

        <!-- Footer -->
        <footer id="footer">
            <section>
                <p>&copy; 2026 Massively Theme. Design by HTML5UP.</p>
            </section>
        </footer>

        @yield('scripts')
    </body>
</html>
