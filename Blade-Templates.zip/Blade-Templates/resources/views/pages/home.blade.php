<!-- resources/views/pages/home.blade.php -->
@extends('layouts.layout')

@section('title', 'Home - Massively Theme')

@section('styles')
<link rel="stylesheet" href="{{ asset('css/custom.css') }}">
@endsection

@section('content')
<section class="post">
    <header class="major">
        <h1>Welcome to Massively</h1>
        <p>A free, fully responsive HTML5 + CSS3 site template.</p>
    </header>
    <div class="image main"><img src="{{ asset('images/pic01.jpg') }}" alt="" /></div>
    <p>This is your dynamic Laravel page using Blade inheritance. You can easily swap content sections while keeping the same layout.</p>
</section>
@endsection

@section('scripts')
<script src="{{ asset('js/main.js') }}"></script>
@endsection
