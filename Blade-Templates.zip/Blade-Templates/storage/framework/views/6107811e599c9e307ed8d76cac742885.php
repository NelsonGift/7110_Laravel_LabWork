<!-- resources/views/layouts/layout.blade.php -->
<!DOCTYPE HTML>
<html>
    <head>
        <title><?php echo $__env->yieldContent('title', 'Massively Theme'); ?></title>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>" />
        <?php echo $__env->yieldContent('styles'); ?>
    </head>
    <body class="is-preload">

        <!-- Header -->
        <header id="header">
            <a href="<?php echo e(url('/')); ?>" class="logo">Massively</a>
        </header>

        <!-- Nav -->
        <nav id="nav">
            <ul class="links">
                <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                <li><a href="<?php echo e(url('/about')); ?>">About</a></li>
                <li><a href="<?php echo e(url('/contact')); ?>">Contact</a></li>
            </ul>
        </nav>

        <!-- Main Content -->
        <div id="main">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

        <!-- Footer -->
        <footer id="footer">
            <section>
                <p>&copy; 2026 Massively Theme. Design by HTML5UP.</p>
            </section>
        </footer>

        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\laragon\www\Blade-Templates\resources\views/welcome.blade.php ENDPATH**/ ?>