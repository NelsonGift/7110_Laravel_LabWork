<!-- resources/views/pages/home.blade.php -->


<?php $__env->startSection('title', 'Home - Massively Theme'); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" href="<?php echo e(asset('css/custom.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="post">
    <header class="major">
        <h1>Welcome to Massively</h1>
        <p>A free, fully responsive HTML5 + CSS3 site template.</p>
    </header>
    <div class="image main"><img src="<?php echo e(asset('images/pic01.jpg')); ?>" alt="" /></div>
    <p>This is your dynamic Laravel page using Blade inheritance. You can easily swap content sections while keeping the same layout.</p>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script src="<?php echo e(asset('js/main.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\Blade-Templates\resources\views/pages/home.blade.php ENDPATH**/ ?>